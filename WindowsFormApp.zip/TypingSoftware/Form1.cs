﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TypingSoftware
{
    public partial class Form1 : Form
    {
        private string text = "";
        private int wrong = 0;
        private int size = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 ";
            var random = new Random();
            size = Convert.ToInt32(textBox2.Text);
            for (int i = 0; i < size; i++)
            {
                int index = random.Next(0,chars.Length);
                text += chars[index];
            }
            richTextBox2.Text = text; 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            textBox7.Text = "39";
            textBox6.Text = "4";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            int inputLength = richTextBox1.Text.Length;
            if (inputLength > 0)
            {
                string target = richTextBox2.Text.Substring(inputLength - 1,1);
                //选取输入字符串中统一位置
                richTextBox1.SelectionStart = inputLength - 1;
                richTextBox1.SelectionLength = 1;
                string input = richTextBox1.SelectedText;
                if (!target.Equals(input))
                {
                    richTextBox1.SelectionColor = Color.Red;
                    wrong++;
                }
                else
                {
                    richTextBox1.SelectionColor = Color.Black;
                }
                //取消选取状态，输入一个字符后接着输入
                richTextBox1.SelectionStart = inputLength;
                richTextBox1.SelectionLength = 0;
            }
            if(richTextBox1.Text.Length == size)
                doSubmition();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox2.Font = fontDialog1.Font;
                richTextBox1.Font = fontDialog1.Font;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            doSubmition();
        }

        private void doSubmition()
        {
            richTextBox1.Text = "共"+size+"个字，输错" + wrong + "个字";

        }


    }
}
