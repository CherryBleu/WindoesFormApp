﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace TankGame
{
    public partial class Form1 : Form
    {
        private int xTank = 0, yTank = 0;
        private int directionTank = 0;
        private int xBoom = 0, yBoom = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //将图片控件置于窗口中心
            xTank = (this.Width - pictureTank.Width) / 2;
            yTank = (this.Height - pictureTank.Height) / 2;
            pictureTank.Location = new Point(xTank, yTank);

            //载入初始图片
            pictureTank.Image = imageTank.Images[0];
        }

        private void boomTimer_Tick(object sender, EventArgs e)
        {
            switch (directionTank)
            {
                case 0://UP
                    yBoom -= 10;
                    break;
                case 1://DOWN
                    yBoom += 10;
                    break;
                case 2://LEFT
                    xBoom -= 10;
                    break;
                case 3://RIGHT
                    xBoom += 10;
                    break;
            }
            pictureBoom.Location = new Point(xBoom, yBoom);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //替换图片
            pictureTank.Image = null;
            switch (e.KeyCode)
            {
                case Keys.Up:
                    yTank -= 10;
                    directionTank = 0;
                    break;
                case Keys.Down:
                    directionTank = 1;
                    yTank += 10;
                    break;
                case Keys.Left:
                    directionTank = 2;
                    xTank -= 10;
                    break;
                case Keys.Right:
                    directionTank = 3;
                    xTank += 10;
                    break;
            }
            pictureTank.Location = new Point(xTank, yTank);
            pictureTank.Image = imageTank.Images[directionTank];

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            pictureBoom.Visible = true;
            switch (directionTank)
            {
                case 0://UP
                    xBoom = xTank + (pictureTank.Width - pictureBoom.Width) / 2;
                    yBoom = yTank -  pictureBoom.Height;
                    break;
                case 1://DOWN
                    xBoom = xTank - (pictureTank.Width - pictureBoom.Width) / 2;
                    yBoom = yTank + pictureBoom.Height;
                    break;
                case 2://LEFT
                    xBoom = xTank - pictureBoom.Width;
                    yBoom = yTank + (pictureBoom.Height - pictureBoom.Height) / 2;
                    break;
                case 3://RIGHT
                    xBoom = xTank + pictureBoom.Width;
                    yBoom = yTank + ( pictureBoom.Height - pictureBoom.Height) * 2;
                    break;
            }
            pictureBoom.Location = new Point(xBoom, yBoom);
            boomTimer.Start();
            SoundPlayer playBomb = new SoundPlayer("\\res\\Bomb.wav");
            playBomb.Load();
            playBomb.Play();
        }
    }
}
